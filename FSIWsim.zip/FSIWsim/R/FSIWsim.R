#' Calculate MS/MS Spectral Similarity
#'
#' @description
#' Main function for calculating similarity between experimental MS/MS spectra
#' and reference database spectra. Uses parallel processing with hierarchical
#' folder structure searching.
#'
#' @param data_path Path to experimental MS/MS data files (CSV format)
#' @param db_MS2 Path to MS2 database folder
#' @param db_NL Path to neutral loss database folder
#' @param iden_dir Output directory for identification results (similarity >= sim_tolerance1)
#' @param anno_dir Output directory for annotation results (similarity >= sim_tolerance2)
#' @param sim_tolerance1 Similarity threshold for identification (default: 0.65)
#' @param sim_tolerance2 Similarity threshold for identification (default: 0.70)
#' @param mztol_tolerance Mass tolerance in Da (default: 0.005)
#' @param parallel Logical, whether to use parallel processing (default: TRUE)
#' @param n_cores Number of cores to use for parallel processing.
#'                If NULL, uses total cores - 2 (default: NULL)
#'
#' @return
#' No return value. Results are written to CSV files in specified output directories.
#'
#' @export
FSIWsim <- function(
    data_path,
    db_MS2,
    db_NL,
    iden_dir,
    anno_dir,
    sim_tolerance1 = 0.65,
    sim_tolerance2 = 0.70,
    mztol_tolerance = 0.005,
    parallel = TRUE,
    n_cores = NULL
) {

  # Load required libraries
  suppressPackageStartupMessages({
    library(readr)
    library(stringr)
    library(openxlsx)
    library(readxl)
    library(gtools)
    library(dplyr)
    library(foreach)
    library(doParallel)
    library(progress)
    library(data.table)
  })

  # Assign parameters
  output_dir1 <- iden_dir
  output_dir2 <- anno_dir
  path1 <- db_MS2
  path2 <- db_NL
  file_path_ms2 <- data_path
  sim_tol1 <- sim_tolerance1
  sim_tol2 <- sim_tolerance2
  mztol <- mztol_tolerance

  # Initialize parallel processing
  if (parallel) {
    total_cores <- parallel::detectCores()
    if (is.null(n_cores)) {
      use_cores <- max(1, total_cores - 2)
    } else {
      use_cores <- min(n_cores, total_cores)
    }
    cl <- parallel::makeCluster(use_cores)
    doParallel::registerDoParallel(cl)
  } else {
    foreach::registerDoSEQ()
  }

  # Clean up cluster on exit
  on.exit({
    if (parallel && exists("cl") && !is.null(cl)) {
      try(parallel::stopCluster(cl), silent = TRUE)
    }
  })

  # Create output directories
  if (!dir.exists(output_dir1)) {
    dir.create(output_dir1, recursive = TRUE)
  }

  if (!dir.exists(output_dir2)) {
    dir.create(output_dir2, recursive = TRUE)
  }

  # Define cosine similarity function
  cosine_similarity <- function(vec1, vec2) {
    dot_product <- sum(vec1 * vec2)
    norm_vec1 <- sqrt(sum(vec1^2))
    norm_vec2 <- sqrt(sum(vec2^2))
    similarity <- dot_product / (norm_vec1 * norm_vec2)
    return(similarity)
  }

  # Get experimental files
  file.pos_diffaqui <- mixedsort(dir(file.path(file_path_ms2), pattern = "\\.csv$", full.names = TRUE))

  if (length(file.pos_diffaqui) == 0) {
    stop("No CSV files found in: ", file_path_ms2)
  }

  # Initialize progress bar
  pb <- progress_bar$new(
    format = "Processing [:bar] :percent | Elapsed: :elapsed | Remaining: :eta",
    total = length(file.pos_diffaqui),
    clear = FALSE,
    width = 60
  )

  # Helper function: extract number from filename
  extract_number_from_filename <- function(filename) {
    parts <- strsplit(basename(filename), "_")[[1]]
    if (length(parts) >= 3) {
      num_part <- sub("\\.csv?$", "", parts[3])
      as.numeric(num_part)
    } else {
      NA_real_
    }
  }

  # Helper function: create 7-level folder structure
  create_7level_folders <- function(value, base_path) {
    # Level 1: 200 Da intervals
    l1_start <- floor(value / 200) * 200
    l1_folder <- sprintf("(%d-%d]", l1_start, l1_start + 200)

    # Level 2: 50 Da intervals
    l2_start <- floor((value - 0.000001) / 50) * 50
    l2_folder <- sprintf("(%d-%d]", l2_start, l2_start + 50)

    # Level 3: 10 Da intervals
    l3_start <- floor((value - 0.000001) / 10) * 10
    l3_folder <- sprintf("(%.1f-%.1f]", l3_start, l3_start + 10)

    # Level 4: 2 Da intervals
    l4_start <- floor((value - 0.000001) / 2) * 2
    l4_folder <- sprintf("(%.2f-%.2f]", l4_start, l4_start + 2)

    # Level 5: 0.5 Da intervals
    l5_start <- floor((value - 0.000001) / 0.5) * 0.5
    l5_folder <- sprintf("(%.3f-%.3f]", l5_start, l5_start + 0.5)

    # Level 6: 0.025 Da intervals
    l6_start <- floor((value - 0.000001) / 0.025) * 0.025
    l6_folder <- sprintf("(%.4f-%.4f]", l6_start, l6_start + 0.025)

    # Level 7: 0.005 Da intervals
    l7_start <- floor((value - 0.000001) / 0.005) * 0.005
    l7_folder <- sprintf("(%.5f-%.5f]", l7_start, l7_start + 0.005)

    # Combine full path
    final_path <- file.path(base_path, l1_folder, l2_folder, l3_folder,
                            l4_folder, l5_folder, l6_folder, l7_folder)

    # Return path if exists
    if (dir.exists(final_path)) final_path else NULL
  }

  # Helper function: get Excel file name without extension
  get_excel_name <- function(path) {
    full_file_name <- basename(path)
    file_name <- sub("\\.xlsx$", "", full_file_name, ignore.case = TRUE)
    return(file_name)
  }

  # Helper function: extract entropy from filename
  extract_entropy_from_filename <- function(filename) {
    parts <- strsplit(basename(filename), "_")[[1]]
    if (length(parts) >= 4) {
      entropy_part <- parts[4]
      entropy_value <- as.numeric(sub("\\.xlsx$", "", entropy_part))
      return(entropy_value)
    } else {
      return(NA_real_)
    }
  }

  # Helper function: analyze file for intensity ratio filtering
  analyze_file <- function(current_file, top_one, mztol, max_row1_I) {
    file_data <- tryCatch({
      readxl::read_excel(current_file, sheet = 1)
    }, error = function(e) NULL)

    if (is.null(file_data)) return(FALSE)

    match_ms2 <- which(abs(file_data$mz - top_one[1]) <= mztol)
    match_neutral <- which(abs(file_data$mz - top_one[2]) <= mztol)

    peak_intensity <- 0
    if (length(match_ms2) > 0) {
      peak_intensity <- max(file_data$relative_intensity[match_ms2])
    } else if (length(match_neutral) > 0) {
      peak_intensity <- max(file_data$relative_intensity[match_neutral])
    }

    if (peak_intensity > 0 && max_row1_I > 0) {
      intensity_ratio <- peak_intensity / max_row1_I
      return(abs(log(intensity_ratio)) <= 1)
    } else {
      return(FALSE)
    }
  }

  # Main processing loop
  result_list_all <- NULL
  result_list <- NULL

  for (n in 1:length(file.pos_diffaqui)) {
    pb$tick()

    # Experimental data preprocessing
    precur_aqi <- as.numeric(str_extract(basename(file.pos_diffaqui[n]), "\\d+\\.\\d+"))
    data_3_new <- read.csv(file.pos_diffaqui[n], 1)
    file_name2 <- gsub("\\.csv$", "", basename(file.pos_diffaqui[n]))

    # Remove peaks with m/z difference > mztol from precursor
    rows_to_remove <- which(data_3_new$mz - precur_aqi > mztol)
    data_3 <- if (length(rows_to_remove) > 0) data_3_new[-rows_to_remove, ] else data_3_new

    # Remove precursor ion peaks
    if (any(abs(data_3$mz - precur_aqi) <= mztol)) {
      data_3 <- data_3[-which(abs(data_3$mz - precur_aqi) <= mztol), ]
    }

    # Keep top 60 most intense peaks
    if (nrow(data_3) > 60) {
      data_3 <- data_3[order(-data_3$intensity), ]
      data_3 <- data_3[1:60, ]
    }

    # Calculate relative intensities and entropy
    total_intensity <- sum(data_3$intensity)
    data_3$relative_intensity <- data_3$intensity / total_intensity

    if (nrow(data_3) > 0) {
      nonzero_intensity <- data_3$relative_intensity[data_3$relative_intensity > 0]
      entropy1 <- sum(-(nonzero_intensity * log(nonzero_intensity)))
      num_peaks <- length(nonzero_intensity)
    } else {
      entropy1 <- 0
      num_peaks <- 0
    }

    data_3 <- data_3[, !colnames(data_3) %in% "relative_intensity"]

    # Process if enough peaks
    if (nrow(data_3) >= 2) {
      data_3$Loss_Neutral <- abs(precur_aqi - data_3$mz)
      data_3$intensity <- sqrt(data_3$intensity)
      total_intensity <- sum(data_3$intensity)
      data_3$relative_intensity <- data_3$intensity / total_intensity
      data_3 <- data_3 %>% mutate(across(everything(), as.numeric))
      data_3 <- arrange(data_3, desc(relative_intensity))

      max_row1 <- as.numeric(data_3[1, c("mz", "Loss_Neutral")])
      max_row2 <- as.numeric(data_3[2, c("mz", "Loss_Neutral")])
      top_one <- max_row1
      top_two <- max_row2
      max_row1_I <- data_3[1, "relative_intensity"]

      # Search for top_one matches in hierarchical folders
      if (length(top_one) > 0) {
        target_folders <- list()
        file_positions <- list()
        file_positions_Npre <- list()

        for (i in 1:length(top_one)) {
          current_value <- top_one[i]
          lower_value <- current_value - mztol
          upper_value <- current_value + mztol
          search_path <- ifelse(i == 1, path1, path2)

          all_target_folders <- unique(c(
            create_7level_folders(current_value, search_path),
            create_7level_folders(lower_value, search_path),
            create_7level_folders(upper_value, search_path)
          ))

          # Collect all Excel files in target folders
          all_files <- unlist(lapply(all_target_folders, function(folder) {
            if (!is.null(folder) && dir.exists(folder)) {
              list.files(path = folder, pattern = "\\.xlsx?$", full.names = TRUE)
            }
          }))

          if (length(all_files) > 0) {
            file_numbers <- sapply(all_files, extract_number_from_filename)

            # Filter files within precursor mass tolerance
            valid_files <- all_files[!is.na(file_numbers) &
                                       file_numbers >= (precur_aqi - mztol) &
                                       file_numbers <= (precur_aqi + mztol)]

            invalid_files <- all_files[!is.na(file_numbers) &
                                         (file_numbers < (precur_aqi - mztol) |
                                            file_numbers > (precur_aqi + mztol))]
          } else {
            valid_files <- character(0)
            invalid_files <- character(0)
          }

          target_folders[[i]] <- all_target_folders
          file_positions[[i]] <- valid_files
          file_positions_Npre[[i]] <- invalid_files
        }

        # Merge file lists from both paths
        file.pos <- c(file_positions[[1]], file_positions[[2]])
        file.pos_Npre <- c(file_positions_Npre[[1]], file_positions_Npre[[2]])

        # Remove duplicates based on Excel file names
        file_names <- sapply(file.pos, get_excel_name)
        unique_indices <- !duplicated(file_names)
        unique_file.pos <- file.pos[unique_indices]

        file_names_Npre <- sapply(file.pos_Npre, get_excel_name)
        unique_indices_Npre <- !duplicated(file_names_Npre)
        unique_file.pos_Npre <- file.pos_Npre[unique_indices_Npre]

        # ---- Step 1: Process files with same precursor (identification) ----
        result_list <- NULL
        if (length(unique_file.pos) > 0) {
          result_list <- foreach(s = 1:length(unique_file.pos), .combine = 'c',
                                 .packages = c('readxl', 'openxlsx', 'dplyr', 'stringr')) %dopar% {
                                   mztol_inner <- 0.005
                                   file <- unique_file.pos[s]
                                   file_name_parts <- str_split(basename(file), "_")[[1]]
                                   second_part_value_str <- gsub("\\.xlsx$", "", file_name_parts[3])
                                   second_part_value <- as.numeric(second_part_value_str)
                                   difference <- abs(precur_aqi - second_part_value)

                                   if (difference <= 0.005) {
                                     # Read database spectrum
                                     data_4_new <- tryCatch({
                                       df <- read_excel(file, sheet = 1)
                                       df %>% mutate(across(everything(), as.numeric))
                                     }, error = function(e) NULL)

                                     if (is.null(data_4_new)) return(NULL)

                                     # Read metadata
                                     sheet2_4 <- read.xlsx(file, sheet = 2, colNames = FALSE)
                                     data_4_new <- arrange(data_4_new, mz)
                                     file_name1 <- gsub("\\.xlsx$", "", basename(file))
                                     mz_values_4 <- as.numeric(str_extract(file_name1, "\\d+\\.\\d+"))
                                     data_4_new$mz <- as.numeric(data_4_new$mz)
                                     data_4 <- data_4_new %>% mutate(across(everything(), as.numeric))

                                     if (nrow(data_4) >= 2) {
                                       data_4$Loss_Neutral <- abs(mz_values_4 - data_4$mz)
                                       data_4$intensity <- sqrt(data_4$intensity)
                                       total_intensity_db <- sum(data_4$intensity)
                                       data_4$relative_intensity <- data_4$intensity / total_intensity_db
                                       data_4 <- data_4 %>% mutate(across(everything(), as.numeric))
                                       data_4 <- arrange(data_4, desc(relative_intensity))

                                       # Extract metadata from sheet 2
                                       extract_info <- function(pattern, replacement) {
                                         matches <- sheet2_4[grepl(pattern, sheet2_4[, 1], ignore.case = TRUE), 1]
                                         if (length(matches) == 0) return(NA)
                                         value <- matches[1]
                                         value <- gsub(replacement, "", value, ignore.case = TRUE)
                                         if (is.na(value) || value == "") NA else value
                                       }

                                       name_4 <- extract_info("Name:", "Name:\\s*")
                                       precursor_type <- extract_info("PRECURSORTYPE:", "PRECURSORTYPE:\\s*")
                                       adduct_type <- extract_info("adductionname:", "adductionname:\\s*")
                                       formula_4 <- extract_info("FORMULA:", "FORMULA:\\s*")
                                       INCHIKEY <- extract_info("INCHIKEY:", "INCHIKEY:\\s*")
                                       smiles_4 <- extract_info("SMILES:", "SMILES:\\s*")

                                       # Calculate similarity
                                       para1 <- 0
                                       para2 <- NULL

                                       if (length(para2) > 0) {
                                         Num.3 <- arrange(data_3[data_3$relative_intensity >= para1, ], desc(relative_intensity))[para2, ]
                                         Num.4 <- arrange(data_4[data_4$relative_intensity >= para1, ], desc(relative_intensity))[para2, ]
                                       } else {
                                         Num.3 <- arrange(data_3[data_3$relative_intensity >= para1, ], desc(relative_intensity))
                                         Num.4 <- arrange(data_4[data_4$relative_intensity >= para1, ], desc(relative_intensity))
                                       }

                                       MzRet1 <- arrange(Num.3, mz)
                                       MzRet2 <- arrange(Num.4, mz)
                                       N1 <- 1:nrow(MzRet1)
                                       N2 <- 1:nrow(MzRet2)
                                       mztol_match <- 0.005
                                       Ind1_mz <- NULL
                                       Ind2_mz <- NULL

                                       for (i in N1) {
                                         mz <- MzRet1[i, "mz"]
                                         for (j in N2) {
                                           if (MzRet2[j, "mz"] >= mz - mztol_match & MzRet2[j, "mz"] <= mz + mztol_match) {
                                             Ind1_mz <- c(Ind1_mz, i)
                                             Ind2_mz <- c(Ind2_mz, j)
                                           }
                                         }
                                       }

                                       MzRet1_mz_sim <- MzRet1 %>% mutate(mzmax = pmax(mz, Loss_Neutral))
                                       colname_mz <- c("mz", "relative_intensity1", "relative_intensity2")

                                       if (length(Ind1_mz) > 0 && length(Ind2_mz) > 0) {
                                         MzRet12_mz_Mat <- cbind(MzRet1_mz_sim[Ind1_mz, c(5, 4)], MzRet2[Ind2_mz, 4])

                                         if (nrow(MzRet12_mz_Mat) >= 2) {
                                           MzRet1_mz_sol <- if (length(Ind1_mz) > 0) MzRet1[-Ind1_mz, ] else MzRet1
                                           MzRet2_mz_sol <- if (length(Ind2_mz) > 0) MzRet2[-Ind2_mz, ] else MzRet2

                                           MzRet1_mz_sol <- MzRet1_mz_sol %>% mutate(mzmin = mz)
                                           MzRet2_mz_sol <- MzRet2_mz_sol %>% mutate(mzmin = mz)

                                           MzRet1_mz_zero <- rep(0, nrow(MzRet1_mz_sol))
                                           MzRet2_mz_zero <- rep(0, nrow(MzRet2_mz_sol))

                                           MzRet1_mz_sol_add <- cbind(MzRet1_mz_sol[c(5, 4)], MzRet1_mz_zero)
                                           MzRet2_mz_sol_add <- cbind(MzRet2_mz_sol[, 5], MzRet2_mz_zero, MzRet2_mz_sol[, 4])

                                           colnames(MzRet12_mz_Mat) <- colname_mz
                                           colnames(MzRet1_mz_sol_add) <- colname_mz
                                           colnames(MzRet2_mz_sol_add) <- colname_mz

                                           MzRet_all <- rbind(MzRet12_mz_Mat, MzRet1_mz_sol_add, MzRet2_mz_sol_add)
                                           data <- MzRet_all
                                           spec1_intensity_wei <- sqrt(data$mz) * data$relative_intensity1
                                           spec2_intensity_wei <- sqrt(data$mz) * data$relative_intensity2

                                           sim <- cosine_similarity(spec1_intensity_wei, spec2_intensity_wei)

                                           result <- data.frame(
                                             Experimental_File = file_name2,
                                             Database_File = file_name1,
                                             Similarity = sim,
                                             Compound_Name = name_4,
                                             Formula = formula_4,
                                             SMILES = smiles_4,
                                             Precursor_Type = precursor_type,
                                             Adduct_Type = adduct_type,
                                             InChIKey = INCHIKEY,
                                             stringsAsFactors = FALSE
                                           )
                                           return(list(result))
                                         }
                                       }
                                     }
                                   }
                                   return(NULL)
                                 }
        }

        result_df <- dplyr::bind_rows(result_list)
        result_list_all[[n]] <- dplyr::bind_rows(result_list)

        # Save identification results if similarity >= threshold
        if (length(result_list_all) > 0 &&
            !is.null(result_list_all[[n]]) &&
            is.data.frame(result_list_all[[n]]) &&
            ncol(result_list_all[[n]]) >= 3) {
          result_list_all[[n]][[3]] <- as.numeric(result_list_all[[n]][[3]])
          result_list_all[[n]] <- result_list_all[[n]] %>% arrange(desc(.[[3]]))
          filtered_data1 <- result_list_all[[n]][result_list_all[[n]]$Similarity >= sim_tol1, ]

          if (nrow(filtered_data1) > 0) {
            output_file1 <- file.path(output_dir1, paste0(file_name2, "_iden_results.csv"))
            write.csv(filtered_data1, output_file1, row.names = FALSE)
          }
        }

        # ---- Step 2: Process files with different precursor (annotation) ----
        if (is.null(result_df) || nrow(result_df) == 0 ||
            (length(result_df) > 0 && nrow(result_df) > 0 && max(result_df$Similarity, na.rm = TRUE) < sim_tol1)) {

          # Search for top_two matches
          target_folders_union <- character()
          file_positions_union <- character()

          if (length(top_two) > 0) {
            for (h in 1:length(top_two)) {
              current_value_2 <- top_two[h]
              lower_value_2 <- current_value_2 - mztol
              upper_value_2 <- current_value_2 + mztol
              search_path_2 <- ifelse(h == 1, path1, path2)

              all_target_folders_2 <- unique(c(
                create_7level_folders(current_value_2, search_path_2),
                create_7level_folders(lower_value_2, search_path_2),
                create_7level_folders(upper_value_2, search_path_2)
              ))

              all_files_2 <- unlist(lapply(all_target_folders_2, function(folder) {
                if (!is.null(folder) && dir.exists(folder)) {
                  list.files(path = folder, pattern = "\\.xlsx?$", full.names = TRUE)
                }
              }))

              target_folders_union <- unique(c(target_folders_union, all_target_folders_2))
              file_positions_union <- unique(c(file_positions_union, all_files_2))
            }
          }

          # Find common files
          matched_paths_i1 <- character(0)
          if (length(file_positions_union) > 0 && length(unique_file.pos_Npre) > 0) {
            common_files <- intersect(
              basename(unique_file.pos_Npre),
              basename(file_positions_union)
            )

            if (length(common_files) > 0) {
              idx_Npre <- match(common_files, basename(unique_file.pos_Npre))
              idx_union <- match(common_files, basename(file_positions_union))
              matched_paths_union <- file_positions_union[idx_union]

              # Remove duplicates
              matched_file_names <- sapply(matched_paths_union, get_excel_name)
              unique_indices_matched <- !duplicated(matched_file_names)
              matched_paths_i1 <- matched_paths_union[unique_indices_matched]
            }
          }

          # Filter by entropy similarity
          if (length(matched_paths_i1) > 0) {
            matched_paths_i1 <- matched_paths_i1[sapply(matched_paths_i1, function(file) {
              file_entropy <- extract_entropy_from_filename(file)
              if (!is.na(file_entropy)) {
                diff_E <- abs(file_entropy - entropy1)
                diff_E <= 0.5
              } else {
                FALSE
              }
            })]
          }

          # Filter by intensity ratio (logFC)
          if (parallel && length(matched_paths_i1) > 0) {
            # Export variables to parallel workers
            parallel::clusterExport(cl, varlist = c("top_one", "mztol", "max_row1_I"))

            valid_matches1 <- foreach(x = 1:length(matched_paths_i1), .combine = 'c',
                                      .packages = 'readxl') %dopar% {
                                        analyze_file(matched_paths_i1[x], top_one, mztol, max_row1_I)
                                      }

            matched_paths_i1 <- matched_paths_i1[valid_matches1]
          } else if (length(matched_paths_i1) > 0) {
            # Sequential processing
            valid_matches1 <- sapply(matched_paths_i1, function(file) {
              analyze_file(file, top_one, mztol, max_row1_I)
            })
            matched_paths_i1 <- matched_paths_i1[valid_matches1]
          }

          # Process filtered files for annotation
          if (length(matched_paths_i1) > 0) {
            result_list <- foreach(p = 1:length(matched_paths_i1), .combine = 'c',
                                   .packages = c('readxl', 'openxlsx', 'dplyr', 'stringr')) %dopar% {
                                     mztol_inner <- 0.005
                                     file <- matched_paths_i1[p]
                                     file_name_parts <- str_split(basename(file), "_")[[1]]
                                     second_part_value_str <- gsub("\\.xlsx$", "", file_name_parts[3])
                                     second_part_value <- as.numeric(second_part_value_str)
                                     difference <- abs(precur_aqi - second_part_value)

                                     if (difference > 0.005) {
                                       # Read database spectrum
                                       data_4_new <- tryCatch({
                                         df <- read_excel(file, sheet = 1)
                                         df %>% mutate(across(everything(), as.numeric))
                                       }, error = function(e) NULL)

                                       if (is.null(data_4_new)) return(NULL)

                                       # Read metadata
                                       sheet2_4 <- tryCatch(read.xlsx(file, sheet = 2, colNames = FALSE), error = function(e) NULL)
                                       if (is.null(sheet2_4)) return(NULL)

                                       data_4_new <- arrange(data_4_new, mz)
                                       file_name1 <- gsub("\\.xlsx$", "", basename(file))
                                       mz_values_4 <- as.numeric(str_extract(file_name1, "\\d+\\.\\d+"))
                                       data_4_new$mz <- as.numeric(data_4_new$mz)
                                       data_4 <- data_4_new %>% mutate(across(everything(), as.numeric))

                                       if (nrow(data_4) >= 2) {
                                         data_4$Loss_Neutral <- abs(mz_values_4 - data_4$mz)
                                         data_4$intensity <- sqrt(data_4$intensity)
                                         total_intensity_db <- sum(data_4$intensity)
                                         data_4$relative_intensity <- data_4$intensity / total_intensity_db
                                         data_4 <- data_4 %>% mutate(across(everything(), as.numeric))
                                         data_4 <- arrange(data_4, desc(relative_intensity))

                                         # Extract metadata
                                         extract_info <- function(pattern, replacement) {
                                           matches <- sheet2_4[grepl(pattern, sheet2_4[, 1], ignore.case = TRUE), 1]
                                           if (length(matches) == 0) return(NA)
                                           value <- matches[1]
                                           value <- gsub(replacement, "", value, ignore.case = TRUE)
                                           if (is.na(value) || value == "") NA else value
                                         }

                                         name_4 <- extract_info("Name:", "Name:\\s*")
                                         precursor_type <- extract_info("PRECURSORTYPE:", "PRECURSORTYPE:\\s*")
                                         adduct_type <- extract_info("adductionname:", "adductionname:\\s*")
                                         formula_4 <- extract_info("FORMULA:", "FORMULA:\\s*")
                                         INCHIKEY <- extract_info("INCHIKEY:", "INCHIKEY:\\s*")
                                         smiles_4 <- extract_info("SMILES:", "SMILES:\\s*")

                                         # Calculate similarity with advanced matching
                                         para1 <- 0
                                         para2 <- NULL
                                         data_4 <- as.data.frame(data_4)

                                         if (length(para2) > 0) {
                                           Num.3 <- arrange(data_3[data_3$relative_intensity >= para1, ], desc(relative_intensity))[para2, ]
                                           Num.4 <- arrange(data_4[data_4$relative_intensity >= para1, ], desc(relative_intensity))[para2, ]
                                         } else {
                                           Num.3 <- arrange(data_3[data_3$relative_intensity >= para1, ], desc(relative_intensity))
                                           Num.4 <- arrange(data_4[data_4$relative_intensity >= para1, ], desc(relative_intensity))
                                         }

                                         # Advanced similarity calculation
                                         MzRet1 <- arrange(Num.3, mz)
                                         MzRet2 <- arrange(Num.4, mz)
                                         N1 <- 1:nrow(MzRet1)
                                         N2 <- 1:nrow(MzRet2)
                                         mztol_match <- 0.005
                                         Loss_NeutralTol <- 0.005
                                         spec_ALL1 <- list()

                                         # Match m/z and neutral loss simultaneously
                                         for (i in N1) {
                                           mz <- MzRet1[i, "mz"]
                                           Loss_Neutral <- MzRet1[i, "Loss_Neutral"]

                                           for (j in N2) {
                                             if (MzRet2[j, "mz"] >= mz - mztol_match & MzRet2[j, "mz"] <= mz + mztol_match) {
                                               ind_both <- which(MzRet2[, "Loss_Neutral"] >= Loss_Neutral - Loss_NeutralTol &
                                                                   MzRet2[, "Loss_Neutral"] <= Loss_Neutral + Loss_NeutralTol)

                                               if (length(ind_both) > 0) {
                                                 mz_mat <- c(MzRet2[j, "mz"], MzRet2[ind_both, "Loss_Neutral"])
                                                 int_mat <- c(MzRet2[j, "relative_intensity"], MzRet2[ind_both, "relative_intensity"])

                                                 int_ind <- which.min(c(
                                                   abs(diff(c(MzRet1[i, "relative_intensity"], MzRet2[j, "relative_intensity"]))),
                                                   abs(diff(c(MzRet1[i, "relative_intensity"], MzRet2[ind_both, "relative_intensity"])))
                                                 ))

                                                 data_same1 <- data.frame(cbind(mz_mat[int_ind], MzRet1[i, "relative_intensity"], int_mat[int_ind]))
                                                 colnames(data_same1) <- if (int_ind == 1) {
                                                   c("mz", "relative_intensity1", "relative_intensity2")
                                                 } else {
                                                   c("Loss_Neutral", "relative_intensity1", "relative_intensity2")
                                                 }
                                                 spec_ALL1[[length(spec_ALL1) + 1]] <- data_same1
                                               }
                                             }
                                           }
                                         }

                                         spec_ALL1 <- Filter(Negate(is.null), spec_ALL1)

                                         if (length(spec_ALL1) > 0) {
                                           # Process matches
                                           Loss_Neutral_same <- do.call(rbind, Filter(function(df) names(df)[1] == "Loss_Neutral", spec_ALL1))
                                           mz_same <- do.call(rbind, Filter(function(df) names(df)[1] == "mz", spec_ALL1))

                                           Loss_Neutral_same_both <- Loss_Neutral_same
                                           mz_same_both <- mz_same

                                           if (!is.null(Loss_Neutral_same_both)) colnames(Loss_Neutral_same_both) <- c("mz", "relative_intensity1", "relative_intensity2")
                                           if (!is.null(mz_same_both)) colnames(mz_same_both) <- c("mz", "relative_intensity1", "relative_intensity2")

                                           mz_Neutral_both <- rbind(Loss_Neutral_same_both, mz_same_both)

                                           # Get unmatched peaks
                                           index_MzRet1_Neu <- NULL
                                           if (!is.null(Loss_Neutral_same) && nrow(Loss_Neutral_same) > 0) {
                                             for (ma in 1:nrow(Loss_Neutral_same)) {
                                               for (nb in 1:nrow(MzRet1)) {
                                                 if (Loss_Neutral_same$Loss_Neutral[ma] >= MzRet1$Loss_Neutral[nb] - Loss_NeutralTol &
                                                     Loss_Neutral_same$Loss_Neutral[ma] <= MzRet1$Loss_Neutral[nb] + Loss_NeutralTol) {
                                                   index_MzRet1_Neu <- c(index_MzRet1_Neu, nb)
                                                 }
                                               }
                                             }
                                           }

                                           index_MzRet1_mz <- NULL
                                           if (!is.null(mz_same) && nrow(mz_same) > 0) {
                                             for (m1 in 1:nrow(mz_same)) {
                                               for (n1 in 1:nrow(MzRet1)) {
                                                 if (mz_same$mz[m1] >= MzRet1$mz[n1] - mztol_match &
                                                     mz_same$mz[m1] <= MzRet1$mz[n1] + mztol_match) {
                                                   index_MzRet1_mz <- c(index_MzRet1_mz, n1)
                                                 }
                                               }
                                             }
                                           }

                                           MzRet1_diff <- if (length(c(index_MzRet1_Neu, index_MzRet1_mz)) > 0) {
                                             MzRet1[-c(index_MzRet1_Neu, index_MzRet1_mz), ]
                                           } else {
                                             MzRet1
                                           }

                                           # Get unmatched peaks from database
                                           index_MzRet2_Neu_base <- NULL
                                           if (!is.null(Loss_Neutral_same) && nrow(Loss_Neutral_same) > 0) {
                                             for (m_base in 1:nrow(Loss_Neutral_same)) {
                                               for (n_base in 1:nrow(MzRet2)) {
                                                 if (Loss_Neutral_same$Loss_Neutral[m_base] >= MzRet2$Loss_Neutral[n_base] - Loss_NeutralTol &
                                                     Loss_Neutral_same$Loss_Neutral[m_base] <= MzRet2$Loss_Neutral[n_base] + Loss_NeutralTol) {
                                                   index_MzRet2_Neu_base <- c(index_MzRet2_Neu_base, n_base)
                                                 }
                                               }
                                             }
                                           }

                                           index_MzRet2_mz <- NULL
                                           if (!is.null(mz_same) && nrow(mz_same) > 0) {
                                             for (m1_base in 1:nrow(mz_same)) {
                                               for (n1_base in 1:nrow(MzRet2)) {
                                                 if (mz_same$mz[m1_base] >= MzRet2$mz[n1_base] - mztol_match &
                                                     mz_same$mz[m1_base] <= MzRet2$mz[n1_base] + mztol_match) {
                                                   index_MzRet2_mz <- c(index_MzRet2_mz, n1_base)
                                                 }
                                               }
                                             }
                                           }

                                           MzRet2_diff <- if (length(c(index_MzRet2_Neu_base, index_MzRet2_mz)) > 0) {
                                             MzRet2[-c(index_MzRet2_Neu_base, index_MzRet2_mz), ]
                                           } else {
                                             MzRet2
                                           }

                                           # Single m/z or neutral loss matching
                                           spec_ALL2 <- NULL
                                           spec_ALL3 <- NULL

                                           if (nrow(MzRet1_diff) > 1 && nrow(MzRet2_diff) > 1) {
                                             for (p_inner in 1:nrow(MzRet1_diff)) {
                                               mzp <- MzRet1_diff[p_inner, "mz"]
                                               Loss_Neutralp <- MzRet1_diff[p_inner, "Loss_Neutral"]

                                               for (q in 1:nrow(MzRet2_diff)) {
                                                 if (MzRet2_diff[q, "mz"] >= mzp - mztol_match & MzRet2_diff[q, "mz"] <= mzp + mztol_match) {
                                                   spec_ALL2 <- rbind(spec_ALL2, c(mzp, MzRet1_diff[p_inner, "relative_intensity"], MzRet2_diff[q, "relative_intensity"]))
                                                 }

                                                 if (MzRet2_diff[q, "Loss_Neutral"] >= Loss_Neutralp - Loss_NeutralTol &
                                                     MzRet2_diff[q, "Loss_Neutral"] <= Loss_Neutralp + Loss_NeutralTol) {
                                                   spec_ALL3 <- rbind(spec_ALL3, c(Loss_Neutralp, MzRet1_diff[p_inner, "relative_intensity"], MzRet2_diff[q, "relative_intensity"]))
                                                 }
                                               }
                                             }
                                           }

                                           if (!is.null(spec_ALL2)) colnames(spec_ALL2) <- c("mz", "relative_intensity1", "relative_intensity2")
                                           if (!is.null(spec_ALL3)) colnames(spec_ALL3) <- c("mz", "relative_intensity1", "relative_intensity2")

                                           # Combine all matches
                                           common_three <- rbind(mz_Neutral_both, spec_ALL2, spec_ALL3)

                                           if (!is.null(common_three) && nrow(common_three) >= 2) {
                                             data <- as.data.frame(common_three)
                                             spec1_intensity_wei <- sqrt(data$mz) * data$relative_intensity1
                                             spec2_intensity_wei <- sqrt(data$mz) * data$relative_intensity2
                                             sim <- cosine_similarity(spec1_intensity_wei, spec2_intensity_wei)

                                             result <- data.frame(
                                               Experimental_File = file_name2,
                                               Database_File = file_name1,
                                               Similarity = sim,
                                               Compound_Name = name_4,
                                               Formula = formula_4,
                                               SMILES = smiles_4,
                                               Precursor_Type = precursor_type,
                                               Adduct_Type = adduct_type,
                                               InChIKey = INCHIKEY,
                                               stringsAsFactors = FALSE
                                             )
                                             return(list(result))
                                           }
                                         }
                                       }
                                     }
                                     return(NULL)
                                   }

            result_df <- dplyr::bind_rows(result_list)
            result_list_all[[n]] <- dplyr::bind_rows(result_list)

            # Save annotation results
            if (length(result_list_all) > 0 &&
                !is.null(result_list_all[[n]]) &&
                is.data.frame(result_list_all[[n]]) &&
                ncol(result_list_all[[n]]) >= 3) {
              result_list_all[[n]][[3]] <- as.numeric(result_list_all[[n]][[3]])
              result_list_all[[n]] <- result_list_all[[n]] %>% arrange(desc(.[[3]]))
              filtered_data2 <- result_list_all[[n]][result_list_all[[n]]$Similarity >= sim_tol2, ]

              if (nrow(filtered_data2) > 0) {
                output_file2 <- file.path(output_dir2, paste0(file_name2, "_sim_results.csv"))
                write.csv(filtered_data2, output_file2, row.names = FALSE)
              }
            }
          }
        }
      }
    }
  }

  # Print completion message
  message("\nProcessing completed!")
  message("Identification results saved to: ", iden_dir)
  message("Annotation results saved to: ", anno_dir)

  invisible(NULL)
}
